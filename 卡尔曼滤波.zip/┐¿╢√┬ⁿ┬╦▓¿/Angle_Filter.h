/*
 * Angle_Filter.h
 *
 *  Created on: 2022��3��27��
 *      Author: ����ɱС��
 */

#ifndef CODE_ANGLE_FILTER_H_
#define CODE_ANGLE_FILTER_H_

#include "headfile.h"
#include "Type.h"

/*************************�����ⲿ����****************************/
extern void Icm20602(void);
extern void Get_Balance_Angle(void);
extern void Kalman_Filter_X( f32 Accel, f32 Gyro );
/*************************�����ⲿ����****************************/
extern f32 Pai;
extern f32 Pitch;
extern f32 Angle_X_Final;
extern f32 Angle_Y_Final;
extern f32 Angle_Z_Final;
extern f32 Gyro_x;
extern f32 Gyro_y;
extern f32 Gyro_z;
extern f32 gyro_dt;
extern f32 dt;
extern f32 Angle_x_temp;

#endif /* CODE_ANGLE_FILTER_H_ */
