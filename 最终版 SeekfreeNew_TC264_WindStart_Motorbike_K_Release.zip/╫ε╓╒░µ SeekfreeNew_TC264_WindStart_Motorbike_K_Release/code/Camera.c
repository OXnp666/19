#include "Camera.h"
#include "WindStart.h"

#pragma section all "cpu1_dsram"
st_Switch Cross_Switch={0};
st_Switch Ring_Switch={0};

/******�˴�����Ϊ���е����У�ע����Сֵ����С��30********/
uint8 controll_h_max = 65;  //�̶����Ϊ20�У�����һ�����ɣ�����һ���Զ�ƫ�ƣ������������У� 80
uint8 controll_h_min;

uint16 time_prevent_check_startline;
float ring_jifen;
/***********�������ȣ����������Ǳ궨������********/
uint8 kuandu_saidao [MT9V03X_H-1] =
{
        166,165,164,163,162,160,160,158,158,
        156,156,155,153,152,151,150,149,148,148,
        146,146,144,144,142,142,140,140,138,138,
        136,136,134,134,132,131,130,129,128,126,
        126,124,124,122,122,120,120,118,117,116,
        114,114,112,112,110,109,108,107,106,105,
        104,103,101,101,99,99,97,97,95,95,
        93,93,91,91,89,89,87,86,85,83,
        82,81,80,79,78,77,76,75,73,73,
        71,71,69,69,67,67,65,65,63,62,
        61,61,59,58,57,55,55,53,53,-67,
        -67,-67,-67,-67,-67,-67,-67,
}; //��������


/**********Ԫ�ش����ṹ��**********/
struct YUAN_SU road_type;
struct YUAN_SU stage;
struct YUAN_SU distance;
struct YUAN_SU num;




//---------------------------------------------------------------------------------------
//  @brief      ͼ���ֵ������
//  @param      void
//  @return     void
//  Sample usage:   Camera_Display();
//---------------------------------------------------------------------------------------
uint8 image_yuanshi[MT9V03X_H][MT9V03X_W];      //ԭʼͼ��
uint8 image_01[MT9V03X_H][MT9V03X_W];           //��ֵ��ͼ��
////����ͷ����ȫ����

extern void Search_Line(void);
void Camera_All_Deal(void)
{
    if(mt9v03x_finish_flag == 1)
    {
        mt9v03x_finish_flag = 0;                                                   //��ͼ��ʹ����Ϻ�  ��������־λ�����򲻻Ὺʼ�ɼ���һ��ͼ��
        Transfer_Camera(mt9v03x_image[0], image_yuanshi[0], MT9V03X_W*MT9V03X_H);  //ͼ��ת��
        Get01change_Dajin();                                                       //ͼ���ֵ��
        Search_Line();                                                             //����
        QianZhan(1, MT9V03X_H-1, 1);                                               // ǰհ���㣨�м�ǰհ������Qianzhan_Middle��
        Ring_Test();
        if(road_type.LeftCirque)
        {
            Handle_Left_Cirque();
        }
        else if(road_type.RightCirque)
        {
            Handle_Right_Cirque();
        }
         Annulus_Deal();
       // Datasend_Side_line(3);

      //  if(time_prevent_check_startline > 2000)
        {
            Check_Starting_Line(90, 80, 1);
           // Outside_protect(100);
        }
        //====������ʶ�����==========
        if(flag_starting_line==1)//ʶ�𵽰�����
        {
            road_type.Starting_LineDis = Car_Distance;
            flag_starting_line = 0;
        }
        if((road_type.Starting_LineDis>=100)&&(Car_Distance >=  road_type.Starting_LineDis+400))//ʶ�𵽰������ܹ�ȥһ�ξ���
        {
            road_type.Starting_Line = 1;
        }

        Calculate_Offset();                                                        //����ƫ��


        if(ON)                                                                      //��Ļ��ʾĬ�Ϲر�
        {
            if(!READ_GPIO(KEY4))//�˴��ǰ���������ʾͼ���Լ���ֹ��cpu0��ʾ��ͻ��Ƶ�
            {
                mutexCpuScreenIsOk = 1;
#if(SCREEN_TYPE == 3 || SCREEN_TYPE == 4)
           // ips200_displayimage03x(image_01[0], MT9V03X_W, MT9V03X_H);             //��ʾ��ֵ��ͼ��
            ips200_show_gray_image(0,0, image_01[0], MT9V03X_W, MT9V03X_H, MT9V03X_W, MT9V03X_H, 0);
           // ips200_displayimage03x(image_yuanshi[0], MT9V03X_W, MT9V03X_H);             //��ʾ��ֵ��ͼ��
#else

               //TFTSPI_Road(0, 0, MT9V03X_H, MT9V03X_W/2, (unsigned char *)Image_Use[0]);
                
               TFT_show_image(0, 0, image_01[0], MT9V03X_W, MT9V03X_H, MT9V03X_W / 2, MT9V03X_H, 0);
#endif

             Blacking();

             mutexCpuScreenIsOk = 0;
        }  
          }//�����ߺ�����
    }
}

void Camera_Parameter_Init(st_Camera *sptr)
{
    sptr->Ramp = 0;
    sptr->barrier = 0;
    sptr->straight = 0;
    sptr->bend  = 0;
}


uint8 search_line_end = 10;
int16 l_line_x[MT9V03X_H], r_line_x[MT9V03X_H], m_line_x[MT9V03X_H];        //����ԭʼͼ������ұ߽������
int16 l_line_x_l[MT9V03X_H], r_line_x_l[MT9V03X_H], m_line_x_l[MT9V03X_H];  //����ԭʼͼ������ұ߽������
uint8 l_lose_value = 0, r_lose_value = 0;                                   //���Ҷ�����
uint8 l_search_flag[MT9V03X_H], r_search_flag[MT9V03X_H];                   //�Ƿ��ѵ��ߵı�־
uint8 l_width, r_width;                                                     //ѭ��������
uint8 l_search_start, r_search_start;                                       //������ʼx����
uint8 r_losemax, l_losemax;
uint8 l_line_x_yuanshi[MT9V03X_H], r_line_x_yuanshi[MT9V03X_H];
uint8 road_width[MT9V03X_H];

//-----------------------------------------------------------------------------------------
//  @brief      ͼ��ת��
//  @param      *p              ��ת�������ַ
//  @param      *q              ת��������ַ
//  @param      pixel_num       ���鳤��
//  @return     void
//  Sample usage:    Transfer_Camera(mt9v03x_image[0], image_yuanshi[0], MT9V03X_W*MT9V03X_H);
//-----------------------------------------------------------------------------------------
void Transfer_Camera(uint8 *p, uint8 *q, int16 pixel_num)
{
    for(int16 i = 0; i < pixel_num; i++)
        *(q +i) = *(p +i);
}

//-----------------------------------------------------------------------------------------
//  @brief      ����ֵ����ֵ��
//  @param      void
//  @return     void
//  Sample usage:    Get01change_Dajin();
//  explain       �ú������������Threshold_Deal(image_yuanshi[0], MT9V03X_W, MT9V03X_H, Threshold_detach);
//-----------------------------------------------------------------------------------------
uint8 Threshold;                //��ֵ
uint8 Threshold_static  = 190;   //��ֵ��̬����225
uint16 Threshold_detach = 255;  //�����㷨�ָ���ֵ
void Get01change_Dajin()
{
      Threshold = Threshold_Deal(image_yuanshi[0], MT9V03X_W, MT9V03X_H, Threshold_detach);

      if (Threshold < Threshold_static)
      {
          Threshold = Threshold_static;
      }

      uint8 thre;
      for(uint8 y = 0; y < MT9V03X_H; y++)  //���￼�ǵ���ͼ���Ե�Ĺ���ƫ��������
      {
        for(uint8 x = 0; x < MT9V03X_W; x++)
        {
          if (x <= 15)                      //��Ӱ��ı�Ե��Χ
            thre = Threshold - 10;          //�޸Ŀɵ���ͼ���Ե��������
          else if (x >= MT9V03X_W-15)
            thre = Threshold - 10;
          else
            thre = Threshold;

          if (image_yuanshi[y][x] >thre)         //��ֵԽ����ʾ������Խ�࣬��ǳ��ͼ��Ҳ����ʾ����
            image_01[y][x] = 255;  //��
          else
            image_01[y][x] = 0;   //��
        }
      }
}


//-----------------------------------------------------------------------------------------
//  @brief      ����ֵ
//  @param      *image              ������ֵ��ͼ������
//  @param      x                   ͼ�����
//  @param      y                   ͼ��߶�
//  @param      pixel_threshold     �����㷨�ָ���ֵ
//  @return     void
//  Sample usage:    Threshold_Deal(image_yuanshi[0], MT9V03X_W, MT9V03X_H, Threshold_detach);
//  explain��       �ú�����Get01change_Dajin();���汻����
//  Threshold = Threshold_Deal(image_yuanshi[0], MT9V03X_W, MT9V03X_H, Threshold_detach);
//-----------------------------------------------------------------------------------------
uint8 Threshold_Deal(uint8 *image, uint16 x, uint16 y, uint32 pixel_threshold)
{
      #define GrayScale 256
      uint16 width = x;
      uint16 height = y;
      int pixelCount[GrayScale];
      float pixelPro[GrayScale];
      int i, j;
      int pixelSum = width * height;
      uint8 threshold = 0;
      uint8* data = image;  //ָ���������ݵ�ָ��
      for (i = 0; i < GrayScale; i++)
      {
        pixelCount[i] = 0;
        pixelPro[i] = 0;
      }

      uint32 gray_sum = 0;
      //ͳ�ƻҶȼ���ÿ������������ͼ���еĸ���
      for (i = 0; i < height; i += 1)
      {
        for (j = 0; j < width; j += 1)
        {
          // if((sun_mode&&data[i*width+j]<pixel_threshold)||(!sun_mode))
          //{
          pixelCount[(
              int)data[i * width + j]]++;  //����ǰ�ĵ������ֵ��Ϊ����������±�
          gray_sum += (int)data[i * width + j];  //�Ҷ�ֵ�ܺ�
          //}
        }
      }

      //����ÿ������ֵ�ĵ�������ͼ���еı���
      for (i = 0; i < GrayScale; i++)
      {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;
      }

      //�����Ҷȼ�[0,255]
      float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;
      w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
      for (j = 0; j < pixel_threshold; j++)
      {
        w0 +=
            pixelPro[j];  //��������ÿ���Ҷ�ֵ�����ص���ռ����֮�� ���������ֵı���
        u0tmp += j * pixelPro[j];  //�������� ÿ���Ҷ�ֵ�ĵ�ı��� *�Ҷ�ֵ

        w1 = 1 - w0;
        u1tmp = gray_sum / pixelSum - u0tmp;

        u0 = u0tmp / w0;    //����ƽ���Ҷ�
        u1 = u1tmp / w1;    //ǰ��ƽ���Ҷ�
        u = u0tmp + u1tmp;  //ȫ��ƽ���Ҷ�
        deltaTmp = w0 * pow((u0 - u), 2) + w1 * pow((u1 - u), 2);
        if (deltaTmp > deltaMax)
        {
          deltaMax = deltaTmp;
          threshold = (uint8)j;     //��������û��ǿ������ת����,���Լ��ӵ�
        }
        if (deltaTmp < deltaMax)
        {
          break;
        }
      }
  return threshold;
}





//-----------------------------------------------------------------------------------------
//  @brief      ƫ�����
//  @param      void
//  @return     void
//  Sample usage:    Calculate_Offset();
//-----------------------------------------------------------------------------------------
uint16 bizhangtime,bizhangertime;
uint8 bizhangset;
int32 offset_1;
float offset;    //����ͷ�����õ���ƫ��(����ƫ����Ǹ�ֵ����ƫ�Ҳ�����ֵ)
void Calculate_Offset()
{
    offset_1 = 0;
    controll_h_min = controll_h_max - 20;
    HDPJ_lvbo(l_line_x, 10, MT9V03X_H -1);


    for(uint8 y = MT9V03X_H -1; y >= search_line_end; y--)
    {
        m_line_x[y] = (l_line_x[y] + r_line_x[y])/2;
    }

    HDPJ_lvbo(m_line_x, 30, MT9V03X_H -1);

    for(uint8 y = controll_h_max; y >= controll_h_min; y--)
    {
        offset_1 += (MT9V03X_W/2 - m_line_x[y]);
    }


    offset = (float)(offset_1/50);
}

//-----------------------------------------------------------------------------------------
//  @brief      �����ߺ�����(��ɫ)
//  @param      void
//  @return     void
//  Sample usage:    Blacking();
//  explain:  �����Ļ��ʾ��ͼ����������žͲ�������
//-----------------------------------------------------------------------------------------
void Blacking()
{
#if(SCREEN_TYPE == 3 || SCREEN_TYPE == 4)
    for(uint8 y=(MT9V03X_H-1); y > search_line_end; y--)
    {
//        ips200_draw_point(l_line_x[y], y, RGB565_GREEN);
//        ips200_draw_point(r_line_x[y], y, RGB565_PURPLE);
//        ips200_draw_point(m_line_x[y] , y, RGB565_BLACK);

        ips200_draw_point(clip(l_line_x[y], 0, MT9V03X_W -1), clip(y, 0, MT9V03X_H -1), RGB565_GREEN);
        ips200_draw_point(clip(r_line_x[y], 0, MT9V03X_W -1), clip(y, 0, MT9V03X_H -1), RGB565_PURPLE);
        ips200_draw_point(clip(m_line_x[y], 0, MT9V03X_W -1), clip(y, 0, MT9V03X_H -1), RGB565_BLACK);
    }

    for(uint8 i = 0; i < MT9V03X_W; i++)
    {
        ips200_draw_point(i, controll_h_max, RGB565_BLUE);
        ips200_draw_point(i, controll_h_min, RGB565_BLUE);

    }
    for(uint8 i=0; i<MT9V03X_H; i++)
    {
        ips200_draw_point(MT9V03X_W/2, i, RGB565_RED);
    }
#else
    for(uint8 y=(MT9V03X_H-1); y > search_line_end; y=y-1)
        {
        if(l_line_x[y] < 0)
               {
                   l_line_x[y] = 0;
               }
               if(r_line_x[y] > MT9V03X_W)
               {
                   r_line_x[y] = MT9V03X_W/2;
               }


            TFTSPI_Draw_Dot(l_line_x[y]/2, y, RGB565_GREEN);
            TFTSPI_Draw_Dot(r_line_x[y]/2, y, RGB565_PURPLE);
            TFTSPI_Draw_Dot( (l_line_x_yuanshi[y] + r_line_x_yuanshi[y])/4, y, RGB565_BLACK);
        }

        for(uint8 i =0; i<MT9V03X_W; i=i+2)
        {
            TFTSPI_Draw_Dot(i, controll_h_max, RGB565_RED);
            TFTSPI_Draw_Dot(i, controll_h_min, RGB565_RED);

        }
        for(uint8 i=0; i<MT9V03X_H; i=i+1)
        {
            TFTSPI_Draw_Dot(MT9V03X_W/4, i, RGB565_RED);
        }
#endif

}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      Ԫ��ʶ����
//  @param      void
//  @return     void
//  Sample usage:   Element_Test();
//-------------------------------------------------------------------------------------------------------------------
void Element_Test()
{
    /******Ԫ��ʶ�𣬵ȴ������Ż�����*******/

}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      Ԫ�ش���
//  @param      void
//  @return     void
//  Sample usage:    Element_Handle();
//-------------------------------------------------------------------------------------------------------------------
void  Element_Handle(void)
{
    /*������Բ��*/
    if(road_type.LeftCirque)
    {
        Element = round_L;
    }
    /*������Բ��*/
    else if(road_type.RightCirque)
    {
       Element = round_R;
    }
    /*�����µ�*/
    if(road_type.Ramp)
    {
    }
    /*����ʮ��*/
    if(road_type.LeftCross)
    {
         Element = cross;
      /***�����ͼ���������账��ʮ�ֵģ��˲��ֿ�ͼ���㷨***/
    }
    else if(road_type.barrier)
    {
     Element = barry;
    }
    /*������·*/
//    if(road_type.Open_road)
//    {
//      Element = openroad;
//    }
}



//-------------------------------------------------------------------------------------------------------------------
//  @brief      ����ͷ�ж��Ƿ����
//  @param      void
//  @return     void
//  Sample usage:    Outside_protect(100);
//-------------------------------------------------------------------------------------------------------------------
uint8 flag_stop;
void Outside_protect(uint8 value)
{
    uint8 j = 0;
    for(int16 x = 0; x < MT9V03X_W - 1; x++)
    {
        if(image_01[MT9V03X_H -2][x] == 0 )  //&& 0 == road_type.barrier &&  Element == nothing
        {
            j++;
            if(j > value )  //����ͷʶ�����
            {
                flag_stop = 1;
                SysFlag.Stop_Run = ON;
            }
        }
    }
}


//-------------------------------------------------------------------------------------------------------------------
//  @brief     ��ȡ��������
//  @param      void
//  @return     void
//  Sample usage:    Get_Width_Road();
//  explain��  ͨ��������������ʹ�����Ĭ�ϴ��� ��cpu_main.c�е�debug_init()������Ĭ�ϴ���;
//-------------------------------------------------------------------------------------------------------------------
void Get_Width_Road(void)
{
    //��ӡ��������
    for(uint8 y = MT9V03X_H-1; y > search_line_end; y--)
    {
        if(y == MT9V03X_H-1)
        {
            printf("%d",  1022);
            printf(",");
        }
        if(y%10 == 0)
        {
            printf("%d", r_line_x[y] - l_line_x[y]);
            printf(",");
            printf(", \n");
        }
        else
        {
            printf("%d", r_line_x[y] - l_line_x[y]);
            printf(",");
        }
    }
}



uint8 r_haveline, l_haveline;
void Have_Count(uint8 type, uint8 start_line, uint8 end_line)
{
    if(type == 1)
    {
       l_haveline = 0;
       for(uint8 i = start_line; i > end_line; i--)
       {
           if(l_search_flag[i] == 1)
           {
               l_haveline++;
           }
       }
    }
    else if(type == 2)
   {
      r_haveline = 0;
      for(uint8 i = start_line; i > end_line; i--)
      {
          if(r_search_flag[i] == 1)
          {
              r_haveline++;
          }
      }
   }
}


/********************���ڼ��Բ���յ�****************/
uint8 left_guai, right_guai;
void Test_guai(uint8 type, uint8 start_line, uint8 end_line)
{
    if(type == 1)
    {
       left_guai = 0;
       for(uint8 i = start_line; i > end_line; i--)
       {
           if(l_search_flag[i +1] == 1 && l_search_flag[i] == 1 && l_search_flag[i -1] == 0 && l_search_flag[i -2] == 0)
           {
               left_guai = i;
               break;
           }
       }
    }
    else if(type == 2)
    {
        right_guai = 0;
        for(uint8 i = start_line; i > end_line; i--)
        {
            if(r_search_flag[i +1] == 1 && r_search_flag[i] == 1 && r_search_flag[i -1] == 0 && r_search_flag[i -2] == 0)
            {
                right_guai = i;
                break;
            }
        }
    }
}
/********************Test_guai_end****************/

/********************���ڼ��յ���Χ��****************/
uint8 Point_Guai_right,Point_Guai_left;
void Count_Point(uint8 type,uint8 start_line)
{
    if(type==1&&start_line!=0)
    {
        Point_Guai_left=0;
        for(uint8 i=start_line-2;i>start_line-7;i--)
          {
              for(uint8 j=l_line_x[start_line+2];j<l_line_x[start_line+2]-10;j--)
              {
                  if(image_01[i][j]==1)
                  {
                      Point_Guai_left++;
                  }
              }
          }
    }
    else if(type==2&&start_line!=0)
    {
        Point_Guai_right=0;
   for(uint8 i=start_line-2;i>start_line-7;i--)
   {
       for(uint8 j=r_line_x[start_line+2];j<r_line_x[start_line-2]+10;j++)
       {
           if(image_01[i][j]==1)
           {
               Point_Guai_right++;
           }
       }
   }
    }
}
/********************Count_Point_end****************/
/*******************ʮ�ּ���ʶ��**********************/
void Annulus_Deal(void)
{
    Have_Count(1, controll_h_max, controll_h_max -40);//��������
    Have_Count(2, controll_h_max, controll_h_max -40);
    Test_guai (1, controll_h_max, 40);
    Test_guai (2, controll_h_max, 40);
    if(Qianzhan_Middle > 100 && left_guai >=10 && right_guai >=10 && r_haveline < 35 && l_haveline < 35)
      {

          road_type.CrossDis = Car_Distance;//��ȡ��ǰ����
          BUZZ_ON;

          if(Cross_Switch.LEFT_Flag==ON)
          {
              road_type.LeftCross = 1;
          }
          else if(Cross_Switch.Right_Flag==ON)
          {
              road_type.RightCross = 1;
          }
      }

    //����
    if(road_type.LeftCross)
       {
           switch(stage.LeftCross)
           {
               case 0://�տ�ʼʶ��ʮ�֣�����ֱ�й�ʮ��
                   //������
                   if(road_width[60] > 160)  //�м���
                   {
                       BUZZ_ON;
                       road_type.CrossDis = Car_Distance;
                       stage.LeftCross = 1;
                   }
               break;
               case 1:
                   //������
                   if(road_width[60] < 120)
                   {
                       BUZZ_OFF;
                       road_type.CrossDis = Car_Distance;
                       stage.LeftCross = 2;
                   }
                   else if((Car_Distance> (road_type.CrossDis+300)))
                   {
                       BUZZ_OFF;
                       stage.LeftCross = 5;

                   }
               break;
               case 2://���˵�һ��ʮ�֣�
                   BUZZ_ON;
                  for(uint8 i = MT9V03X_H-1; i > 10; i--)
                     {
                      r_line_x[i]= r_line_x[i]-30;
                     }
                  if(Qianzhan_Middle > 80 && left_guai ==0 && right_guai !=0)
                  {
                      BUZZ_OFF;
                      road_type.CrossDis = Car_Distance;
                      stage.LeftCross = 3;
                  }
                  else  if((Car_Distance> (road_type.CrossDis+2000)))//û�м�⵽
                  {
                      BUZZ_OFF;
                      stage.LeftCross = 5;

                  }

              break;//���˵�һ��ʮ��
               case 3:
                   for(uint8 i = MT9V03X_H-1; i > 10; i--)
                       {
                       r_line_x[i]= r_line_x[i]-45;
                       l_line_x[i]= l_line_x[i]-10;
                       }
                   if((Car_Distance> (road_type.CrossDis+400)))
                   {
                       BUZZ_OFF;
                       road_type.CrossDis = Car_Distance;
                       stage.LeftCross = 5;
                   }
               break;
               case 5:
                    stage.LeftCross = 0;
                    road_type.LeftCross = 0;
                    BUZZ_OFF;
                break;
           }


         }
}

/********************���ڼ��Բ��****************/
void Ring_Test(void)
{
    Have_Count(1, controll_h_max, controll_h_max -40);
    Have_Count(2, controll_h_max, controll_h_max -40);
    Test_guai (1, controll_h_max, 40);
    Test_guai (2, controll_h_max, 40);

//    Count_Point(1,left_guai);
//    Count_Point(2,right_guai);

    if(Qianzhan_Middle > 100 && left_guai != 0 && right_guai == 0 && r_haveline >= 38 && l_haveline < 30)
    {
        if(Ring_Switch.LEFT_Flag == ON)
        {
        road_type.LeftCirque = 1;
        road_type.LeftCirtimes = System_Ticks;//��ȡ��ǰʱ��
        }
    }
    if(Qianzhan_Middle > 100 && left_guai == 0 && right_guai != 0 && r_haveline < 30 && l_haveline >= 38)
    {
        if(Ring_Switch.Right_Flag == ON)
        {
            road_type.RightCirque = 1;
        }

    }
}
/********************Ring_Test_end****************/


/********************���ڼ���Ƿ��б�Ԫ�أ�ʵ�ʳ��������****************/
void Test_Element_first(void)
{
    if(road_type.LeftCirque)
    {
        while(1)
        {
          go_motor(0,0);
          ips200_show_string(100, 90, "left");
        }
    }
    if(road_type.RightCirque)
    {
        while(1)
        {
          go_motor(0,0);
          ips200_show_string(0, 90, "right");
        }
    }
}
/********************Test_Element_first_end****************/


/********************���ڴ���Բ��****************/
uint8 L_integration_flag = 0, R_integration_flag = 0;
void Handle_Left_Cirque(void)
{
    if(road_type.LeftCirque)
    {
        switch(stage.LeftCirque)
        {
            case 0:
                if(road_width[60] > 140)  //�м���
                {
                    BUZZ_ON;
                    road_type.LeftCirqueDis = Car_Distance;
                    stage.LeftCirque = 1;
                }
            break;
            case 1:
                if(road_width[60] < 120)
                {
                    BUZZ_OFF;
                    stage.LeftCirque = 2;
                }
            break;
            case 2:
                if(road_width[60] > 130|| (System_Ticks > (road_type.LeftCirtimes + 3000)))
                {
                    BUZZ_ON;
                    stage.LeftCirque = 3;
                    road_type.LeftCirqueDis = Car_Distance;

                }
            break;
            case 3://����

               // if(Left_CirqueIntegration > 6000)
                if((Car_Distance> (road_type.LeftCirqueDis+200)))
                {
                    BUZZ_OFF;
                    stage.LeftCirque = 4;

                }
            break;
            case 4://����
               // if(Left_CirqueIntegration > 10000)
                if(Car_Distance > (road_type.LeftCirqueDis + 1100))
                {

                    BUZZ_ON;
                    stage.LeftCirque = 5;
                }
            break;
            case 5: //����
               // if(Left_CirqueIntegration > 15000)
                if(Car_Distance > (road_type.LeftCirqueDis + 1600))
                {
                    BUZZ_OFF;
                    stage.LeftCirque=6;
                }
            break;
            case 6:
               // if(Left_CirqueIntegration > 20000)  //ֱ��
                if(Car_Distance > (road_type.LeftCirqueDis + 1700))
                {
                    BUZZ_ON;
                    stage.LeftCirque = 7;
                }
            break;
        }
        if(stage.LeftCirque == 0 || stage.LeftCirque == 1 || stage.LeftCirque == 2 )  //ֱ��
        {
            for(uint8 i = MT9V03X_H-1; i > 10; i--)
            {
                l_line_x[i] = r_line_x[i] - kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.LeftCirque == 3)  //����
        {
            L_integration_flag = 1;
            for(uint8 i = MT9V03X_H-1; i > 10; i--)
            {
                r_line_x[i] = l_line_x[i] + kuandu_saidao[MT9V03X_H-1 -i];
            }
        }
        if(stage.LeftCirque ==4 )  //����
        {

        }
        if(stage.LeftCirque == 5)  //����
        {

            for(uint8 i = MT9V03X_H-1; i > 10; i--)
            {
                r_line_x[i] = l_line_x[i] + kuandu_saidao[MT9V03X_H -1 -i]-30;
            }
        }
        if(stage.LeftCirque == 6)  //ֱ��
        {

            for(uint8 i = MT9V03X_H-1; i > 10; i--)
            {
                l_line_x[i] = r_line_x[i] - kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.LeftCirque == 7)
        {
            stage.LeftCirque = 0;
            L_integration_flag = 0;
            road_type.LeftCirque = 0;
            BUZZ_OFF;
        }
    }
}
/********************Handle_Left_Cirque_end****************/

/********************���ڴ���Բ��****************/
void Handle_Right_Cirque(void)
{
    if(road_type.RightCirque)
    {
        switch(stage.RightCirque)
        {
            case 0:
                if(road_width[60] > 120)
                {
                    stage.RightCirque = 1;
                }
            break;
            case 1:
                if(road_width[60] < 100)
                {
                    stage.RightCirque = 2;
                }
            break;
            case 2:
                if(road_width[60] > 113)
                {
                    stage.RightCirque = 3;
                }
            break;
            case 3:
                if(Right_CirqueIntegration > 500)
                {
                    stage.RightCirque = 4;
                }
            break;
            case 4:
                if(Right_CirqueIntegration > 2500)
                {
                    stage.RightCirque = 5;
                }
            break;
            case 5:
                if(Right_CirqueIntegration > 3000)
                {
                    stage.RightCirque = 6;
                }
            break;
            case 6:
                if(Right_CirqueIntegration > 3500)
                {
                    stage.RightCirque = 7;
                }
            break;
        }
        if(stage.RightCirque == 0||stage.RightCirque == 1||stage.RightCirque == 2)  //ֱ��
        {
            for(uint8 i = MT9V03X_H -1; i > 10; i--)
            {
                r_line_x[i] = l_line_x[i] + kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.RightCirque == 3) //����
        {
            BUZZ_ON;
            R_integration_flag = 1;
            for(uint8 i = MT9V03X_H -1; i > 10; i--)
            {
                l_line_x[i] = r_line_x[i] - kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.RightCirque == 4) //����
        {
            BUZZ_OFF;
        }
        if(stage.RightCirque == 5)  //����
        {
            BUZZ_ON;
            for(uint8 i = MT9V03X_H -1; i > 10; i--)
            {
                l_line_x[i] = r_line_x[i] - kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.RightCirque == 6)  //ֱ��
        {
            BUZZ_OFF;
            for(uint8 i = MT9V03X_H -1; i > 10; i--)
            {
                r_line_x[i] = l_line_x[i] + kuandu_saidao[MT9V03X_H -1 -i];
            }
        }
        if(stage.RightCirque == 7)
        {
            stage.RightCirque = 7;
            R_integration_flag = 0;
        }
    }
}
/********************Handle_Left_Cirque_end****************/


/********************���ڽ��ٶȻ���****************/
uint32 Left_CirqueIntegration = 0, Right_CirqueIntegration = 0;
void Integration(void)
{
   if(L_integration_flag == 1)
   {
       Left_CirqueIntegration += 0.1*fabs(ring_jifen);
   }
   if(R_integration_flag == 1)
   {
       Right_CirqueIntegration += 0.1*fabs(ring_jifen);
   }
}
/********************Test_Element_first_end****************/


void Datasend_Side_line(uint8 type)
{
    if(type == 1)
    {
        for (uint8 i = 0; i < MT9V03X_H - 2; i++)
        {
           if(i == 0)
           {
               printf("start");
               printf("\n");
           }
           else
           {
               printf("%d", l_line_x[i]);
               printf(",");
               if(i%10 == 0)
               {
                   printf("\n");
               }
           }
        }
    }
    else if(type == 2)
    {
        for (uint8 i = 0; i < MT9V03X_H - 2; i++)
        {
           if(i == 0)
           {
               printf("start");
               printf("\n");
           }
           else
           {
               printf("%d", r_line_x[i]);
               printf(",");
               if(i%10 == 0)
               {
                   printf("\n");
               }
           }
        }
    }
    else if(type == 3)
    {
        for (uint8 i = MT9V03X_H - 1; i > 2; i--)
        {
           if(i == MT9V03X_H - 1)
           {
               printf("start");
               printf("\n");
           }
           else
           {
               printf("%d", r_line_x[i] - l_line_x[i]);
               printf(",");
               if(i%10 == 0)
               {
                   printf("\n");
               }
           }
        }
    }
}

//-------------------------------------------------------------------------------------------------------------------
// �������     ��һ���㻭ʮ��
// ����˵��     void
// ���ز���     uint32 ��ѹ
// ʹ��ʾ��     Voltage_Detection(ADC_VOLTAGE);
//-------------------------------------------------------------------------------------------------------------------
void Draw_Cross(uint16 x_point, uint16 y_point, const uint16 color, uint8 num)
{
    for (uint8 x = x_point -num; x < x_point +num; x++)
    {
        ips200_draw_point(x, y_point, color);
    }
    for (uint8 y = y_point -num; y < y_point +num; y++)
    {
        ips200_draw_point(x_point, y, color);
    }
}


//������
uint8 length_l_line, length_r_line;
void Check_bianxian(uint8 type)
{
    uint8 length_l_line, length_r_line;
    if(type == 1)
    {
        length_l_line = 0;
        for(uint8 y = MT9V03X_H-1; y > 10; y--)
        {
            if((l_line_x[y] <= l_line_x[y-1]) && l_line_x[y] != 0)   //���߲����߲ż���ֱ������
            {
                length_l_line++;
            }
        }
    }
    else if(type == 2)
    {
        length_r_line = 0;
        for(uint8 y = MT9V03X_H-1; y > 10; y--)
        {
            if((r_line_x[y] >= r_line_x[y-1]) && r_line_x[y] != MT9V03X_W -1)
            {
                length_r_line++;
            }
        }
    }
}

int clip(int x, int low, int up)
{
    return x > up ? up : x < low ? low : x;
}


float fclip(float x, float low, float up)
{
    return x > up ? up : x < low ? low : x;
}


//���߻���ƽ��ֵ�˲�
int16 Sum1;
void HDPJ_lvbo(int16 data[], uint8 N, uint8 size)
{//data[] Ҫ�˲�������   N �˲�ǿ��   size �˲���ʼ��
    Sum1 = 0;
    for(uint8 j = 0; j < size; j++)
    {
        if(j < N /2)
        {
            for(uint8 k = 0; k < N; k++)
            {
                Sum1 += data[j +k];
            }
            data[j] = Sum1 /N;
        }
        else if(j < size - N/2)
        {
            for(uint8 k = 0; k < N/2; k++)
            {
                Sum1 += (data[j +k] +data[j -k]);
            }
            data[j] = Sum1 /N;
        }
        else
        {
            for(uint8 k = 0; k < size -j; k++)
            {
                Sum1 += data[j +k];
            }
            for(uint8 k =0; k <(N -size +j); k++)
            {
                Sum1 += data[j -k];
            }
            data[j] = Sum1 /N;
        }
        Sum1 = 0;
    }
}

#pragma section all restore

