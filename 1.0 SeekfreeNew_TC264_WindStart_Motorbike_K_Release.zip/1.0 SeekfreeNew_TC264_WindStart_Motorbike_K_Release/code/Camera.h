#ifndef _camera_h
#define _camera_h
#include "WindStart.h"
#include "zf_common_headfile.h"

//˵ �������꺯���Ĳ�������Ϊ����ʽ��ֻ��Ϊ������ֵ
#define Limit_Min_Max(data, min, max) (((data) > (max)) ? (max):(((data) < (min)) ? (min):(data)))

//�������ͽṹ��
typedef struct YUAN_SU{
     int16 Ramp;                   //�µ�
     int16 barrier;                //���
     int16 straight;               //ֱ��
     int16 bend;                   //���
     int16 Cross;                  //ʮ��
     int16 LeftCirque;             //�󻷵�
     int16 RightCirque;            //�һ���
     int16 L_RoadBlock;            //���ϰ�
     int16 R_RoadBlock;            //���ϰ�
     int16 Starting_Line;          //������
}st_Camera;
extern struct YUAN_SU road_type;
extern struct YUAN_SU stage;
extern struct YUAN_SU distance;
extern struct YUAN_SU num;
extern uint16 time_prevent_check_startline;
extern float ring_jifen;

extern uint8 Threshold_static;   //��ֵ��̬����225
////����ͷ���߲���///
void Camera_All_Deal(void);
void Camera_Parameter_Init(st_Camera *sptr);
void Transfer_Camera(uint8 * p, uint8 *q, int16 pixel_num);
void Get01change_Dajin(void);
uint8 Threshold_Deal(uint8* image, uint16 col, uint16 row, uint32 pixel_threshold);

////Ԫ��ʶ�𲿷�///
void Element_Test(void);
void Check_Starting_Line(uint8 start_point, uint8 end_point, uint8 qiangdu);
extern uint8 flag_starting_line;
extern uint8 black_blocks_l, black_blocks_r;
extern uint8 cursor_l, cursor_r;
void Check_Zhidao(void);
extern uint8 sudu_yingzi;
void Check_Bianxian(uint8 type);
extern uint8 length_l, length_r;
void Diuxian_Weizhi_Test(uint8 type, uint8 startline, uint8 endline);
extern uint8 diuxian_hang, budiuxian_hang;
uint8 Bianxian_Guaidian(uint8 type, uint8 startline, uint8 endline );

////Ԫ�ش�������///
void Element_Handle(void);
void Get_Width_Road(void);
/*****************����Բ�����ֺ���************/
void Ring_Test(void);
void Roadblock_Test(void);
void Cross_Test(void);
void Check_Corss_L(uint8 type);

extern uint8 cross_l_1, cross_l_2;
extern uint8 cross_r_1, cross_r_2;

void Have_Count(uint8 type,uint8 start_line,uint8 end_line);
void QianZhan(uint8 type,uint8 start_line,uint8 end_line);  //type:1,���߰׵㣬2��ߣ�3�ұ�
void Test_Element_first(void);
void Test_guai(uint8 type,uint8 start_line,uint8 end_line);
void Count_Point(uint8 type,uint8 start_line);

uint16 Check_Cirque(uint8 type, uint8 startline);
void Handle_Left_Cirque(void);
void Handle_Right_Cirque(void);

void Integration(void);

void HDPJ_lvbo(int16 data[], uint8 N, uint8 size);

/*******************end************************/


/*****************����Բ�����ֱ���************/
extern uint8 r_haveline, l_haveline;
extern uint8 Qianzhan_Middle, Qianzhan_Left, Qianzhan_Right;
extern uint8 Point_Guai_right,Point_Guai_left;
extern uint8 left_guai,right_guai;

extern uint8 L_integration_flag,R_integration_flag;
extern uint32 Left_CirqueIntegration,Right_CirqueIntegration;
/*******************end************************/

////����ƫ�����������////

extern uint8 image_yuanshi[MT9V03X_H][MT9V03X_W];
extern uint8 image_01[MT9V03X_H][MT9V03X_W];
extern uint8 Threshold;
extern uint8 search_line_end;
extern uint8 road_width[MT9V03X_H];
extern uint8 l_lose_value, r_lose_value;
extern uint8 r_losemax, l_losemax;
extern uint8 chang_point_l,chang_point_r;

extern uint8 l_search_flag[MT9V03X_H], r_search_flag[MT9V03X_H];                   //�Ƿ��ѵ��ߵı�־
extern uint8 l_width, r_width;                                                     //ѭ��������
extern uint8 l_search_start, r_search_start;                                       //������ʼx����
extern uint8 l_line_x_yuanshi[MT9V03X_H], r_line_x_yuanshi[MT9V03X_H];

void Calculate_Offset(void);
extern int32 offset_1;
extern float offset;
extern uint8 flag_stop;
void Blacking(void);
extern uint8 controll_h_max ;  //
extern uint8 controll_h_min ;
void Outside_protect(uint8 value);
extern int16 l_line_x[MT9V03X_H], r_line_x[MT9V03X_H], m_line_x[MT9V03X_H];
extern int16 l_line_x_l[MT9V03X_H], r_line_x_l[MT9V03X_H], m_line_x_l[MT9V03X_H];
extern uint8 kuandu_saidao [MT9V03X_H-1];

void Datasend_Side_line(uint8 type);
void Draw_Cross(uint16 x_point, uint16 y_point, const uint16 color, uint8 num);

void Check_bianxian(uint8 type);
extern uint8 length_l_line, length_r_line;

int clip(int x, int low, int up);
float fclip(float x, float low, float up);


#endif

