#include <fq_show.h>
#pragma section all "cpu0_dsram"

void Show_Roadbolck(void)
{
    ips200_show_int (0, 120, offset, 3);                ips200_show_string(50, 120, "offset");
    ips200_show_uint(0, 140, road_type.L_RoadBlock, 3); ips200_show_string(50, 140, "L_RoadBlock");
    ips200_show_uint(0, 160, road_type.R_RoadBlock, 3); ips200_show_string(50, 160, "R_RoadBlock");
    ips200_show_uint(0, 180, distance.L_RoadBlock, 3);  ips200_show_string(50, 180, "D_LeftCirque");
    ips200_show_uint(0, 200, distance.R_RoadBlock, 3);  ips200_show_string(50, 200, "D_R_RoadBlock");
    ips200_show_uint(0, 220, l_lose_value, 3);          ips200_show_string(50, 220, "l_lose_value");
    ips200_show_uint(0, 240, r_lose_value, 3);          ips200_show_string(50, 240, "r_lose_value");
    }

void Show_Left_Cirque()
{
    ips200_show_uint(0, 120, l_haveline, 3);            ips200_show_string(50, 120, "l_haveline");
    ips200_show_uint(0, 140, r_haveline, 3);            ips200_show_string(50, 140, "r_haveline");

    ips200_show_uint(0, 160, length_l_line, 3);         ips200_show_string(50, 160, "length_l_line");
    ips200_show_uint(0, 180, length_r_line, 3);         ips200_show_string(50, 180, "length_r_line");

    ips200_show_uint(0, 200, road_type.LeftCirque, 3);  ips200_show_string(50, 200, "T_LeftCirque");

    ips200_show_uint(0, 220, Qianzhan_Middle, 3);       ips200_show_string(50, 220, "Qianzhan_Middle");
    ips200_show_uint(0, 240, stage.LeftCirque, 3);      ips200_show_string(50, 240, "stage.LC");
    ips200_show_uint(0, 260, road_width[60], 3);        ips200_show_string(50, 260, "road_width[60]");

    ips200_show_uint(0, 280, Left_CirqueIntegration, 4);    ips200_show_string(50, 280, "Left_CirqueIntegration");

    Draw_Cross(l_line_x[left_guai], left_guai, RGB565_BLUE, 15);
    Draw_Cross(l_line_x[right_guai], right_guai, RGB565_BLUE, 15);
}

void Show_Right_Cirque()
{
    ips200_show_uint(0, 120, l_haveline, 3);            ips200_show_string(50, 120, "l_haveline");
    ips200_show_uint(0, 140, r_haveline, 3);            ips200_show_string(50, 140, "r_haveline");

    ips200_show_uint(0, 160, length_l_line, 3);         ips200_show_string(50, 160, "length_l_line");
    ips200_show_uint(0, 180, length_r_line, 3);         ips200_show_string(50, 180, "length_r_line");

    ips200_show_uint(0, 200, road_type.RightCirque, 3); ips200_show_string(50, 200, "T_RightCirque");

    ips200_show_uint(0, 220, Qianzhan_Middle, 3);       ips200_show_string(50, 220, "Qianzhan_Middle");
    ips200_show_uint(0, 240, stage.RightCirque, 3);     ips200_show_string(50, 240, "stage.RC");
    ips200_show_uint(0, 260, road_width[60], 3);            ips200_show_string(50, 260, "road_width[60]");
    ips200_show_uint(0, 280, Right_CirqueIntegration, 4);   ips200_show_string(50, 280, "Right_CirqueIntegration");

    Draw_Cross(l_line_x[left_guai], left_guai, RGB565_BLUE, 15);
    Draw_Cross(l_line_x[right_guai], right_guai, RGB565_BLUE, 15);
}



void Show_Check_Starting_Line()
{
    ips200_show_uint(0, 120, flag_starting_line, 3);                 ips200_show_string(50, 120, "flag_starting_line");
    ips200_show_uint(0, 140, time_prevent_check_startline, 4);       ips200_show_string(50, 140, "ti_precheck_startl");
}


#pragma section all restore
