#ifndef _DATADMP_H_
#define _DATADMP_H_
#include "zf_common_headfile.h"
typedef struct
{
	float x;
	float y;
	float z;
} _xyz_f_st;

typedef struct
{
	float lpf_1;

	float out;
}_lf_t;



#define ABS(x) ( (x)>0?(x):-(x) )//????
#define LIMIT( x,min,max ) ( (x) < (min)  ? (min) : ( (x) > (max) ? (max) : (x) ) )
#define my_pow(a) ((a)*(a))
extern _xyz_f_st vec_err_i;
extern	_xyz_f_st x_vec;
extern	_xyz_f_st y_vec;
extern	_xyz_f_st z_vec;
extern	_xyz_f_st a_acc;
extern	_xyz_f_st w_acc;

static float invSqrt(float x) ;
float my_sqrt(float number);
//void Q_IMUupdata(ACCGYRO_DateDeal *gyro_var);//ԭ���ط������������

#endif
