#ifndef _fq_show_h
#define _fq_show_h
#include "WindStart.h"
#include "zf_common_headfile.h"


void Show_Roadbolck(void);

void Show_Left_Cirque(void);

void Show_Right_Cirque(void);

void Show_Check_Starting_Line(void);

void Show_Judge_Cirque(void);

void Show_Cross(void);

#endif
